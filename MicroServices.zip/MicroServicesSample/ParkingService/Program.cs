using System;
using System.Net.Http;
using System.Reflection;
using Microsoft.Owin.Hosting;
using NServiceBus;

[assembly: AssemblyVersion("1.0.0.0")]

static class Program
{
    public static IBus bus = null;

    static void Main()
    {
        Console.WriteLine("XPark Parking microservice version {0}", Assembly.GetExecutingAssembly().GetName().Version);
        
        using (bus = StartEventing())
        using (StartWebApi())
        {
            Console.WriteLine("Press ENTER to quit.");
            Console.ReadLine(); 
        }
    }

    private static IDisposable StartWebApi()
    {
        string baseAddress = "http://localhost:9000/";

        Console.WriteLine("Web API listening at {0}", baseAddress);
        // Start OWIN host 
        return WebApp.Start<Startup>(url: baseAddress);
    }

    private static IBus StartEventing()
    {
        var busConfiguration = new BusConfiguration();
        busConfiguration.EndpointName("MicroServicesSample.PubSub.ParkingService");
        busConfiguration.UsePersistence<InMemoryPersistence>();
        busConfiguration.EnableInstallers();
        ConventionsBuilder conventions = busConfiguration.Conventions();
        conventions.DefiningEventsAs(t => t.Namespace != null && t.Namespace == "MicroServicesSample.Messages");
        var startableBus = Bus.Create(busConfiguration);
        return startableBus.Start();
    }
}