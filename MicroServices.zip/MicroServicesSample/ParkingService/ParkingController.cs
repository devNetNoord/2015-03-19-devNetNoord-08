﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using MicroServicesSample.Messages;

public class ParkingController : ApiController
{
    public static Dictionary<int, int> ParkingCapacity = new Dictionary<int, int>();
    private const int MaximumCapacity = 5;


    // GET api/parking/5 
    public CapacityInfo Get(int id)
    {
        if (!ParkingCapacity.ContainsKey(id)) ParkingCapacity[id] = 0;
        int capacity = ParkingCapacity[id];
        return new CapacityInfo() { LocationId = id, Capacity = capacity };
    }

    // POST api/parking 
    public void Post([FromBody] int id)
    {
        if (!ParkingCapacity.ContainsKey(id)) ParkingCapacity[id] = 0;
        int capacity = ParkingCapacity[id];

        if (capacity < MaximumCapacity)
        {
            capacity++;
            Console.WriteLine("Parking capacity for location {0}: {1}", id, capacity);
            ParkingCapacity[id] = capacity;
        }
        else
        {
            Guid eventId = Guid.NewGuid();
            var eventMessage = new ParkingFullEventMessage
            {
                EventId = eventId,
                Time = DateTime.Now.Second > 30 ? (DateTime?)DateTime.Now : null,
                LocationId = id
            };

            Console.WriteLine("Publishing ParkingFull event for location {0}", id);
            Program.bus.Publish(eventMessage);
        }
    }
}

public class CapacityInfo
{
    public int LocationId { get; set; }
    public int Capacity { get; set; }
}
