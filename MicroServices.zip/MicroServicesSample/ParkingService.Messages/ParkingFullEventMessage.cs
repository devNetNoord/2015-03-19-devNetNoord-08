using System;
using System.Reflection;

[assembly: AssemblyVersion("1.0.0.0")]

namespace MicroServicesSample.Messages
{
    [Serializable]
    public class ParkingFullEventMessage
    {
        public Guid EventId { get; set; }
        public DateTime? Time { get; set; }
        public int LocationId { get; set; }
    }
}