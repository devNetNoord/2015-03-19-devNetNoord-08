using System;
using System.Reflection;
using MicroServicesSample.Messages;
using NServiceBus;
using NServiceBus.Features;

[assembly: AssemblyVersion("1.0.0.0")]

static class Program
{
    static void Main()
    {
        BusConfiguration configuration = new BusConfiguration();
        ConventionsBuilder conventions = configuration.Conventions();
        conventions.DefiningEventsAs(t => t.Namespace != null
            && t.Namespace == "MicroServicesSample.Messages" && t.Name.EndsWith("EventMessage"));
        configuration.EndpointName("MicroServicesSample.PubSub.AvailabilityService");
        configuration.DisableFeature<AutoSubscribe>();
        configuration.UsePersistence<InMemoryPersistence>();
        configuration.EnableInstallers();
        configuration.AssembliesToScan(Assembly.GetExecutingAssembly());
        var startableBus = Bus.Create(configuration);
        using (var bus = startableBus.Start())
        {
            bus.Subscribe<ParkingFullEventMessage>();
            Console.WriteLine("XPark Availability microservice version {0}", Assembly.GetExecutingAssembly().GetName().Version);
            Console.WriteLine("Subscribed to ParkingFull event messages.");
            Console.WriteLine("Press ENTER to quit.");
            Console.ReadLine();
            bus.Unsubscribe<ParkingFullEventMessage>();
        }
    }
}