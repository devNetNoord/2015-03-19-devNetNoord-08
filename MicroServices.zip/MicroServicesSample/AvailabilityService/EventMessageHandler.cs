using System;
using System.Net.WebSockets;
using System.Threading;
using BlueKeyDigital;
using MicroServicesSample.Messages;
using NServiceBus;

namespace MicroServicesSample.Messages
{
    [Serializable]
    public class ParkingFullEventMessage
    {
        public Guid EventId { get; set; }
        public DateTime? Time { get; set; }
        public int LocationId { get; set; }
    }
}

public class EventMessageHandler : IHandleMessages<ParkingFullEventMessage>
{
    private static CircuitBreaker breaker = new CircuitBreaker(2, 60000);

    public void Handle(ParkingFullEventMessage message)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(string.Format("Event received with Id {0} at time {1}.", message.EventId, message.Time));
        Console.WriteLine(string.Format("Details: Parking Location ID: {0}.", message.LocationId));

        try
        {
            breaker.Execute(() =>
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Reporting full parking (across bad connection)...");
                if (message.LocationId > 1337)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan; 
                    Console.WriteLine("\nOops. Something went wrong.");
                    Thread.Sleep(5000);
                    throw new TimeoutException("A timeout occurred in the operation call.");
                }
                Console.WriteLine("Succes");
            });
        }
        catch (OpenCircuitException)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Circuit is open. Failed immediately.");
        }
        catch (Exception)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Caught exception. Circuit breaker service level is {0}", breaker.ServiceLevel);
        }
    }
}